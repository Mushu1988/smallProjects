﻿using LibraryProject.Models;
using LibraryProject.Models.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LibraryProject.Controllers
{
    public class HomeController : Controller
    {
        private BookRepo repository = new BookRepo();
        private int pageSize = 10;

        protected int CurrentPage
        {
            get
            {
                int page;
                page = int.TryParse(Request.QueryString["page"], out page) ? page : 1;
                return page > MaxPage ? MaxPage : page;
            }
        }

        protected int MaxPage
        {
            get
            {
                return (int)Math.Ceiling((decimal)repository.Books.Count() / pageSize);
            }
        }

        // GET: Home
        [Authorize]
        public ActionResult Index(string option, string search)
        {
            ViewBag.User= HttpContext.User.Identity.Name;

            IEnumerable<Book> showBooks = repository.Books;
            if (option == "Title")
            {
                showBooks = repository.Books.Where(x => x.Title.Contains(search) || search == null).OrderBy(b => b.ISBN).Skip((CurrentPage - 1) * pageSize).Take(pageSize).ToList();
            }
            else if (option == "Author")
            {
                showBooks = repository.Books.Where(x => x.Author.Contains(search) || search == null).OrderBy(b => b.ISBN).Skip((CurrentPage - 1) * pageSize).Take(pageSize).ToList();
            }
            else if (option=="Language")
            {
                showBooks = repository.Books.Where(x => x.Language==search || search == null).OrderBy(b => b.ISBN).Skip((CurrentPage - 1) * pageSize).Take(pageSize).ToList();
            }
            else if (option == "Subject")
            {
                showBooks = repository.Books.Where(x => x.Subject == search || search == null).OrderBy(b => b.ISBN).Skip((CurrentPage - 1) * pageSize).Take(pageSize).ToList();
            }
            else
            {
                showBooks = repository.Books.OrderBy(b => b.ISBN).Skip((CurrentPage - 1) * pageSize).Take(pageSize);
            }

            ViewBag.MaxPage = MaxPage;
            ViewBag.CurrentPage = CurrentPage;
            return View(showBooks);
        }

    }
}