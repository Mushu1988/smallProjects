﻿using LibraryProject.Models;
using LibraryProject.Models.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LibraryProject.Controllers
{
    public class CartController : Controller
    {
        private BookRepo repository;
        public CartController()
        {
            repository = new BookRepo();
        }

        public ViewResult Index(Cart cart, string returnUrl)
        {
            return View(new CartIndexViewModel
            {
                Cart = cart,
                ReturnUrl = returnUrl
            });
        }

        [HttpPost]
        public ActionResult Index(Cart cart)
        {
            if (cart.Lines.Count() == 0)
            {
                ModelState.AddModelError("", "There are no books to reserve.");
            }

            if (ModelState.IsValid)
            {
                cart.Clear();
                return View("Completed");
            }
            else
            {
                return View("Index", cart);
            }
        }


        public ActionResult AddToCart(Cart cart, string bookId, string returnUrl)
        {
            Book book = repository.Books
                .FirstOrDefault(g => g.ISBN == bookId);

            if (book != null)
            {
                cart.AddItem(book);
            }
            return RedirectToAction("Index", new { returnUrl });
        }

        public RedirectToRouteResult RemoveFromCart(Cart cart, string bookId, string returnUrl)
        {
            Book book = repository.Books
                .FirstOrDefault(g => g.ISBN == bookId);

            if (book != null)
            {
                cart.RemoveLine(book);
            }
            return RedirectToAction("Index", new { returnUrl });
        }

    }
}