﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace LibraryProject.Models
{
    public class LoanDetail
    {
        [Key]
        public int LoanDetailsId { get; set; }
        public Loan Loan { get; set; }
        public Book Book { get; set; }
    }
}