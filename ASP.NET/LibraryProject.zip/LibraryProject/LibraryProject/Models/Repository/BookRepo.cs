﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace LibraryProject.Models.Repository
{
    public class BookRepo
    {
        private EFDbContext context = new EFDbContext();

        public IEnumerable<Book> Books
        {
            get { return context.Books; }
        }

        public void SaveBook(Book book)
        {
            Book dbEntry = context.Books.Find(book.ISBN);
            if (dbEntry != null)
            {
                dbEntry.ISBN = book.ISBN;
                dbEntry.Title = book.Title;
                dbEntry.Author = book.Author;
                dbEntry.Subject = book.Subject;
                dbEntry.Publisher = book.Publisher;
                dbEntry.Language = book.Language;
                dbEntry.Status = book.Status;
            }
            context.SaveChanges();
        }

        public Book DeleteBook(int bookId)
        {
            Book dbEntry = context.Books.Find(bookId);
            if (dbEntry != null)
            {
                context.Books.Remove(dbEntry);
                context.SaveChanges();
            }
            return dbEntry;
        }

        public IEnumerable<Loan> Loans
        {
            get
            {
                return context.Loans.Include(l => l.LoanDetails.Select(ol => ol.Book));
            }
        }

        
        public void SaveLoan(Loan loan)
        {
            if (loan.LoanId == 0)
            {
                loan = context.Loans.Add(loan);

                foreach (LoanDetail detail in loan.LoanDetails)
                {
                    context.Entry(detail.Book).State
                        = EntityState.Modified;
                }

            }
            else
            {
                Loan dbLoan = context.Loans.Find(loan.LoanId);
                if (dbLoan != null)
                {
                    dbLoan.UserId = loan.UserId;
                    dbLoan.Date = loan.Date;
                }
            }
            context.SaveChanges();
        }
    }
}