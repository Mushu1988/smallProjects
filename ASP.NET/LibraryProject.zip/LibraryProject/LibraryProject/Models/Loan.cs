﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace LibraryProject.Models
{
    public class Loan
    {
        [Key]
        public int LoanId { get; set; }
        public string UserId { get; set; }
        public DateTime Date { get; set; }
        public virtual List<LoanDetail> LoanDetails { get; set; }
    }
}